﻿#include <iostream>
#include <vector>
#include <time.h>

using namespace std;

#define MAX 711
#define MAXIMUM 711000000

// Funkcija za zadatak 1a
void zadatak_1_a() {
    int x1, x2, x3, x4;
    unsigned long long cnt = 0;

    time_t t1, t2;
    time(&t1);

    for (x1 = 1; x1 <= MAX; x1++) {
        for (x2 = 1; x2 <= MAX; x2++) {
            for (x3 = 1; x3 <= MAX; x3++) {
                for (x4 = 1; x4 <= MAX; x4++) {
                    cnt++;
                    if ((x1 + x2 + x3 + x4 == MAX) && (x1 * x2 * x3 * x4 == MAXIMUM)) {
                        cout << "x1: " << (double)x1 / 100 << "$"
                            << ", x2: " << (double)x2 / 100 << "$"
                            << ", x3: " << (double)x3 / 100 << "$"
                            << ", x4: " << (double)x4 / 100 << "$" << endl;
                    }
                }
            }
        }
    }

    time(&t2);
    cout << "Broj iteracija: " << cnt << endl;
    cout << "Slozenost O(" << MAX << "^4)." << endl;
    cout << "Vreme izvrsavanja programa: " << (t2 - t1) << " [s] " << endl;
}

// Funkcija za zadatak 1b
void zadatak_1_b() {
    int x1, x2, x3;
    unsigned long long cnt = 0;

    time_t t1, t2;
    time(&t1);

    for (x1 = 1; x1 <= MAX; x1++) {
        for (x2 = 1; x2 <= MAX; x2++) {
            for (x3 = 1; x3 <= MAX; x3++) {
                int x4 = MAX - x1 - x2 - x3;
                cnt++;
                if (x4 > 0 && x1 * x2 * x3 * x4 == MAXIMUM) {
                    cout << "x1: " << (double)x1 / 100 << "$"
                        << ", x2: " << (double)x2 / 100 << "$"
                        << ", x3: " << (double)x3 / 100 << "$"
                        << ", x4: " << (double)x4 / 100 << "$" << endl;
                }
            }
        }
    }

    time(&t2);
    cout << "Broj iteracija: " << cnt << endl;
    cout << "Slozenost O(" << MAX << "^3)." << endl;
    cout << "Vreme izvrsavanja programa: " << (t2 - t1) << " [s] " << endl;
}

// Funkcija za zadatak 1c
void zadatak_1_c() {
    long long number = MAXIMUM;
    unsigned long long cnt = 0;
    int x1, x2, x3;
    vector<int> factors;

    time_t t1, t2;
    time(&t1);

    // Pronađi delitelje broja
    for (int i = 1; i <= MAX; i++) {
        if (number % i == 0) {
            factors.push_back(i);
        }
    }

    for (int i = 0; i < factors.size(); i++) {
        for (int j = 0; j < factors.size(); j++) {
            for (int k = 0; k < factors.size(); k++) {
                x1 = factors[i];
                x2 = factors[j];
                x3 = factors[k];
                int x4 = MAX - x1 - x2 - x3;
                cnt++;
                if (x4 > 0 && x1 * x2 * x3 * x4 == MAXIMUM) {
                    cout << "x1: " << (double)x1 / 100 << "$"
                        << ", x2: " << (double)x2 / 100 << "$"
                        << ", x3: " << (double)x3 / 100 << "$"
                        << ", x4: " << (double)x4 / 100 << "$" << endl;
                }
            }
        }
    }

    time(&t2);
    cout << "Broj iteracija: " << cnt << endl;
    cout << "Slozenost O(" << factors.size() << "^3)." << endl;
    cout << "Vreme izvrsavanja programa: " << (t2 - t1) << " [s] " << endl;
}

int main() {
    
    cout << endl << "Zadatak 1b:" << endl;
    zadatak_1_b();

    cout << endl << "Zadatak 1c:" << endl;
    zadatak_1_c();

    //NAJSPORIJI JE PA ZATO POSLEDNJE
    cout << "Zadatak 1a:" << endl;
    zadatak_1_a();

    return 0;
}
